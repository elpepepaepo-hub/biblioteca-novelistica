# Biblioteca Novelística — Interfaz visual v0.6.0 (prototipo)

Incluye `ui/` (interfaz HTML/CSS/JS adaptable y accesible) y `integration/bridge.ts` (adaptador MCP Apps a compilar y validar). `backend/` conserva las fuentes del prototipo autogestionado v0.5.0.

## Vista previa local

Desde `ui/`: `python -m http.server 8080` y abrir http://127.0.0.1:8080. La vista previa muestra **datos ficticios**. No hay escritura ni almacenamiento de manuscritos en el navegador.

## Para conectarlo realmente a ChatGPT

1. Desplegar el servidor MCP autogestionado bajo HTTPS y configurar OAuth real.
2. Instalar el SDK oficial `@modelcontextprotocol/ext-apps` y compilar `integration/bridge.ts` para el frontend; validar la API de la versión instalada.
3. Registrar la UI como recurso `ui://` servido por el MCP y asociar la herramienta que la abre mediante `_meta.ui.resourceUri`, siguiendo la especificación vigente de MCP Apps. Esto **no está integrado en el servidor** todavía.
4. Probar descubrimiento de recursos, apertura de UI, autenticación y llamadas a herramientas desde un host ChatGPT compatible.
5. Confirmar permisos antes de operaciones de escritura y aprobación del canon. No introducir tokens ni contraseñas en la interfaz.

## Alcance y limitaciones

- Implementado: navegación, fichas de personajes, lugares, resumen, línea de tiempo visual, alertas, propuestas/canon, selector de novelas, vista de conexión, diseño móvil, renderizado con escape HTML y puente opcional para llamadas MCP.
- No implementado: recurso MCP Apps servido desde el backend, OAuth desplegado, sincronización real completa, edición/canonización desde UI, integración probada en ChatGPT.
- No subir este código a un repositorio público si deseas mantener el complemento privado.
