/** MCP Apps host bridge adapter; requires @modelcontextprotocol/ext-apps at build time.
 * Keep this isolated: API compatibility must be verified against deployed SDK.
 */
import { App } from '@modelcontextprotocol/ext-apps';
const app = new App({name:'Biblioteca Novelística',version:'0.6.0'});
(window as any).bibliotecaMcpCall = async (name:string,args:Record<string,unknown>) => {
  return app.callServerTool({name,arguments:args});
};
app.connect();
