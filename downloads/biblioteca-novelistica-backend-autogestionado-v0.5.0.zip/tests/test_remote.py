import os
from pathlib import Path
import jwt
from cryptography.hazmat.primitives.asymmetric import rsa
from fastapi.testclient import TestClient
from biblioteca import remote

key=rsa.generate_private_key(public_exponent=65537,key_size=2048)
class SigningKey:
    key=key.public_key()
class FakeJwks:
    def get_signing_key_from_jwt(self,token):return SigningKey()

def token(sub):return jwt.encode({'sub':sub,'iss':'https://identity.example.test/','aud':'biblioteca','iat':1700000000,'exp':4102444800},key,algorithm='RS256')

def test_remote_isolation_and_canon(monkeypatch,tmp_path):
    monkeypatch.setattr(remote,'ISSUER','https://identity.example.test/')
    monkeypatch.setattr(remote,'AUDIENCE','biblioteca')
    monkeypatch.setattr(remote,'JWKS_URL','https://identity.example.test/jwks')
    monkeypatch.setattr(remote,'DATA_DIR',tmp_path)
    monkeypatch.setattr(remote,'_jwks',FakeJwks())
    with TestClient(remote.app) as client:
        assert client.get('/novels').status_code==401
        a={'Authorization':'Bearer '+token('alice')}
        b={'Authorization':'Bearer '+token('bob')}
        assert client.get('/novels',headers={'Authorization':'Bearer bad'}).status_code==401
        response=client.post('/novels',headers=a,json={'title':'Mi novela'})
        assert response.status_code==200,response.text
        ids=response.json()
        assert len(client.get('/novels',headers=a).json())==1
        assert client.get('/novels',headers=b).json()==[]
        assert client.get('/novels/'+ids['novel_id']+'/entities',headers=b).status_code==404
        ent=client.post('/novels/'+ids['novel_id']+'/entities',headers=a,json={'kind':'personaje','name':'Ana'}).json()['entity_id']
        claim=client.post('/novels/'+ids['novel_id']+'/claims',headers=a,json={'entity_id':ent,'branch_id':ids['branch_id'],'property':'edad','value':20,'chapter':'1','source_version':'1'}).json()['claim_id']
        assert client.get('/novels/'+ids['novel_id']+'/entities/'+ent+'/claims',headers=a).json()[0]['status']=='propuesta'
        assert client.post('/novels/'+ids['novel_id']+'/claims/'+claim+'/approve',headers=a,json={'reason':'Confirmado por escritora'}).json()['status']=='canon'
        assert client.get('/novels/'+ids['novel_id']+'/entities/'+ent+'/claims',headers=b).status_code==404
        assert len(list(tmp_path.glob('*.sqlite3')))==2

def test_jwt_validation_rejects_bad_audience_and_expired(monkeypatch):
    monkeypatch.setattr(remote,'ISSUER','https://identity.example.test/')
    monkeypatch.setattr(remote,'AUDIENCE','biblioteca')
    monkeypatch.setattr(remote,'_jwks',FakeJwks())
    bad=jwt.encode({'sub':'alice','iss':'https://identity.example.test/','aud':'other','iat':1700000000,'exp':4102444800},key,algorithm='RS256')
    expired=jwt.encode({'sub':'alice','iss':'https://identity.example.test/','aud':'biblioteca','iat':1600000000,'exp':1600000100},key,algorithm='RS256')
    for t in (bad,expired):
        try:remote.verify_token(t)
        except jwt.PyJWTError:pass
        else:raise AssertionError('Invalid token accepted')

def test_subject_cannot_escape_database_directory(monkeypatch,tmp_path):
    monkeypatch.setattr(remote,'DATA_DIR',tmp_path)
    p=remote.database_path('../../admin')
    assert p.parent==tmp_path and p.suffix=='.sqlite3'
    assert '..' not in p.name
