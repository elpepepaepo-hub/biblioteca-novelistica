import json
import pytest
from biblioteca.installation_wizard import validate, generate, HOSTS, IDENTITIES

@pytest.mark.parametrize('host', ['render','railway','fly','self-hosted'])
@pytest.mark.parametrize('identity', list(IDENTITIES))
def test_all_supported_remote_profiles(host,identity,tmp_path):
    profile=validate(host,'sqlite','oauth',identity)
    path=generate(profile,tmp_path/(host+'-'+identity))
    assert (path/'plan.json').is_file()
    assert not json.loads((path/'plan.json').read_text())['ready_for_chatgpt']
    assert not any('password=' in p.read_text().lower() for p in path.rglob('*') if p.is_file())

@pytest.mark.parametrize('host', ['render','railway','fly','self-hosted'])
@pytest.mark.parametrize('auth', ['off-local','token-local'])
def test_public_auth_cannot_be_disabled(host,auth):
    with pytest.raises(ValueError,match='BLOQUEADO'):
        validate(host,'sqlite',auth,'auth0')

def test_postgres_unimplemented():
    with pytest.raises(ValueError,match='PostgreSQL'):
        validate('render','postgres','oauth','auth0')

def test_loopback_only():
    with pytest.raises(ValueError,match='loopback'):
        validate('local','sqlite','off-local',bind='0.0.0.0')

def test_public_url_must_be_real_https():
    for url in ('http://example.org','https://example.org/path','https://user:pass@example.org','https://demo.example'):
        with pytest.raises(ValueError): validate('render','sqlite','oauth','auth0',url)

def test_no_credentials_in_generated_local(tmp_path):
    p=generate(validate('local','sqlite','off-local'),tmp_path/'local')
    assert (p/'compose.local.yaml').is_file()
    assert 'BIBLIOTECA_TOKEN' in (p/'compose.local.yaml').read_text()
    assert not (p/'.env').exists()

def test_cli_noninteractive(tmp_path):
    from biblioteca.installation_wizard import main
    assert main(['--mode','persistente','--host','railway','--identity','auth0','--output',str(tmp_path/'cli')])==0
    assert (tmp_path/'cli'/'railway.toml').is_file()
