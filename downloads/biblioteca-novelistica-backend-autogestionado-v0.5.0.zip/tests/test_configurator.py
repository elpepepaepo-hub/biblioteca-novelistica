import pytest
from biblioteca.configurator import config, HOSTS, IDENTITIES

def test_provider_matrix():
    for h in HOSTS:
        for p in IDENTITIES:
            c=config(h,p,'https://novels.example.org','https://id.example.org/','biblioteca-api','https://id.example.org/jwks')
            assert c['mcp_endpoint']=='https://novels.example.org/mcp'
            assert c['requires_deployment_and_oauth_registration']

def test_no_insecure_urls():
    with pytest.raises(ValueError):
        config('render','auth0','http://localhost','https://id.example.org','api','https://id.example.org/jwks')
