import pytest
from biblioteca.core import Store,ConflictError

def setup():
 s=Store();ids=s.create_novel('Reino de plata');n,b=ids['novel_id'],ids['branch_id'];return s,n,b

def test_approval_provenance_and_state_history():
 s,n,b=setup();e=s.add_entity(n,'local','personaje','Aldric')
 c=s.add_claim(n,'local',e,b,'caracter','inocente',valid_from=1,valid_to=10,chapter='1',source_version='v1')
 assert s.claims(n,'local',e)[0]['status']=='propuesta'
 s.approve_claim(n,'local',c,'autor')
 d=s.add_claim(n,'local',e,b,'caracter','desconfiado',valid_from=11,valid_to=20,chapter='12')
 s.approve_claim(n,'local',d,'autor')
 assert len(s.claims(n,'local',e))==2
 assert s.claims(n,'local',e)[0]['chapter']=='1'
 assert len(s.export_novel(n,'local')['tables']['canon_decision'])==2

def test_conflict_blocks_canon_and_logs_issue():
 s,n,b=setup();e=s.add_entity(n,'local','personaje','Aldric')
 a=s.add_claim(n,'local',e,b,'edad',21,valid_from=1,valid_to=5)
 s.approve_claim(n,'local',a,'autor')
 c=s.add_claim(n,'local',e,b,'edad',80,valid_from=4,valid_to=7)
 with pytest.raises(ConflictError):s.approve_claim(n,'local',c,'autor')
 assert s.claims(n,'local',e)[1]['status']=='propuesta'
 assert s.export_novel(n,'local')['tables']['issue'][0]['severity']=='grave'

def test_branch_isolation_and_alternatives():
 s,n,b=setup();e=s.add_entity(n,'local','personaje','Aldric')
 a=s.add_claim(n,'local',e,b,'vivo',True);s.approve_claim(n,'local',a,'autor')
 alt=s.branch(n,'local','muere-capitulo-8',b)
 c=s.add_claim(n,'local',e,alt,'vivo',False,status='alternativa')
 assert len(s.claims(n,'local',e,b))==1
 assert s.claims(n,'local',e,alt)[0]['status']=='alternativa'

def test_timeline_non_linear_and_subplot():
 s,n,b=setup();event=s.add_entity(n,'local','acontecimiento','Coronacion')
 s.add_event_time(n,'local',event,b,start_tick=300,narrative_order=1,chronology_mode='no_lineal')
 s.add_event_time(n,'local',event,b,start_tick=100,narrative_order=9,chronology_mode='no_lineal')
 assert [r['start_tick'] for r in s.timeline(n,'local',b)]==[100,300]
 sub=s.add_entity(n,'local','subtrama','El espia')
 s.set_subplot(n,'local',sub,b,'abierta',last_scene_order=2)
 assert s.audit(n,'local',b,latest_scene_order=10)[0]['code']=='SUBPLOT_DORMANT'

def test_cross_novel_rejected():
 s,n,b=setup();other=s.create_novel('Otro',owner='persona-2');e=s.add_entity(n,'local','personaje','E')
 with pytest.raises(KeyError):s.add_claim(other['novel_id'],'persona-2',e,other['branch_id'],'edad',10)
 with pytest.raises(KeyError):s.entities(n,'persona-2')

def test_roundtrip_export_import_and_provenance():
 s,n,b=setup();doc=s.add_document(n,'local','Manuscrito','2');scene=s.add_scene(n,'local','El inicio','1',doc,1)
 e=s.add_entity(n,'local','personaje','Aldric');c=s.add_claim(n,'local',e,b,'poder','fuego',scene_id=scene,document_id=doc,source_version='2')
 s.approve_claim(n,'local',c,'autor');s.add_scene_version(n,'local',scene,b,'rama-1','Aldric despierta.')
 export=s.export_novel(n,'local');new=s.import_novel(export,owner='persona-3')['novel_id']
 assert new!=n
 assert len(s.entities(new,'persona-3'))==1
 assert s.export_novel(new,'persona-3')['tables']['claim'][0]['source_version']=='2'
 assert s.export_novel(new,'persona-3')['tables']['canon_decision'][0]['actor']=='autor'

def test_requires_explicit_approval():
 s,n,b=setup();e=s.add_entity(n,'local','personaje','Aldric')
 with pytest.raises(ValueError):s.add_claim(n,'local',e,b,'edad',21,status='canon')
 with pytest.raises(ValueError):s.add_claim(n,'local',e,b,'edad',21,valid_from=10,valid_to=5)
