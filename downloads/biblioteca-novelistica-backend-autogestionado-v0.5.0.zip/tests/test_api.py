import importlib
from fastapi.testclient import TestClient

def test_token_auth_and_api(monkeypatch,tmp_path):
    monkeypatch.setenv('BIBLIOTECA_AUTH','token')
    monkeypatch.setenv('BIBLIOTECA_TOKEN','A'*40)
    monkeypatch.setenv('BIBLIOTECA_DB_PATH',str(tmp_path/'test.sqlite3'))
    from biblioteca import api
    importlib.reload(api)
    with TestClient(api.app) as client:
        assert client.get('/health').status_code==200
        assert client.get('/novels').status_code==401
        h={'Authorization':'Bearer '+'A'*40}
        r=client.post('/novels',json={'title':'La niebla'},headers=h)
        assert r.status_code==200,r.text
        ids=r.json()
        e=client.post(f"/novels/{ids['novel_id']}/entities",json={'kind':'personaje','name':'Vera'},headers=h).json()['entity_id']
        c=client.post(f"/novels/{ids['novel_id']}/claims",json={'entity_id':e,'branch_id':ids['branch_id'],'property':'estado','value':'viva'},headers=h).json()['claim_id']
        approved=client.post(f"/novels/{ids['novel_id']}/claims/{c}/approve",json={'actor':'autor'},headers=h)
        assert approved.status_code==200,approved.text
        assert approved.json()['status']=='canon'
        assert len(client.get(f"/novels/{ids['novel_id']}/export",headers=h).json()['tables']['claim'])==1
