"""Hosted per-writer API. Every endpoint uses an independently verified JWT subject."""
import hashlib
import os
import re
from contextlib import asynccontextmanager
from pathlib import Path
import jwt
from jwt import PyJWKClient
from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import JSONResponse
from .core import Store, ConflictError
from pydantic import BaseModel, Field
class NovelIn(BaseModel):
    title:str=Field(min_length=1)
    description:str=''
class EntityIn(BaseModel):
    kind:str
    name:str=Field(min_length=1)
    description:str=''
class ClaimIn(BaseModel):
    entity_id:str
    branch_id:str
    property:str=Field(min_length=1)
    value:object
    status:str='propuesta'
    valid_from:int|None=None
    valid_to:int|None=None
    chapter:str|None=None
    scene_id:str|None=None
    document_id:str|None=None
    source_version:str|None=None
    author_note:str=''
class ApprovalIn(BaseModel):
    reason:str=Field(min_length=1)
class BranchIn(BaseModel):
    name:str=Field(min_length=1)
    parent_id:str
class TimeIn(BaseModel):
    entity_id:str
    branch_id:str
    start_tick:int|None=None
    end_tick:int|None=None
    calendar:str='personalizado'
    narrative_order:int|None=None
    chapter:str|None=None
    chronology_mode:str='lineal' 

ISSUER=os.getenv('BIBLIOTECA_OIDC_ISSUER','')
AUDIENCE=os.getenv('BIBLIOTECA_OIDC_AUDIENCE','')
JWKS_URL=os.getenv('BIBLIOTECA_OIDC_JWKS_URL','')
DATA_DIR=Path(os.getenv('BIBLIOTECA_DATA_DIR','./persistent-data'))
# Only RS256; asymmetric JWT verification, never HS256 or unsigned tokens.
_jwks=None

def verifier():
    global _jwks
    if _jwks is None:
        if not (ISSUER.startswith('https://') and AUDIENCE and JWKS_URL.startswith('https://')):
            raise RuntimeError('OIDC issuer, audience and JWKS HTTPS URL are required')
        _jwks=PyJWKClient(JWKS_URL,cache_jwk_set=True,lifespan=300)
    return _jwks

def verify_token(token):
    key=verifier().get_signing_key_from_jwt(token).key
    payload=jwt.decode(token,key,algorithms=['RS256'],issuer=ISSUER,audience=AUDIENCE,options={'require':['exp','iat','sub','iss','aud']},leeway=30)
    sub=payload.get('sub')
    if not isinstance(sub,str) or not sub or len(sub)>512:raise ValueError('Invalid subject')
    return sub

def database_path(subject):
    # No user-controlled path components. Separate files and owner checks in Store.
    digest=hashlib.sha256(subject.encode('utf-8')).hexdigest()
    return DATA_DIR/(digest+'.sqlite3')

@asynccontextmanager
async def lifespan(app):
    if not (ISSUER.startswith('https://') and AUDIENCE and JWKS_URL.startswith('https://')):
        raise RuntimeError('Configure a real OAuth/OIDC issuer, audience and JWKS URL before startup')
    DATA_DIR.mkdir(parents=True,exist_ok=True,mode=0o700)
    yield

app=FastAPI(title='Biblioteca Novelística remote API',version='0.3.0',lifespan=lifespan,docs_url=None,redoc_url=None)

@app.middleware('http')
async def authenticate(request:Request,call_next):
    if request.url.path=='/health':return await call_next(request)
    value=request.headers.get('authorization','')
    if not value.startswith('Bearer '):return JSONResponse({'detail':'Bearer token required'},status_code=401,headers={'WWW-Authenticate':'Bearer'})
    try:request.state.subject=verify_token(value[7:])
    except Exception:return JSONResponse({'detail':'Invalid or expired token'},status_code=401,headers={'WWW-Authenticate':'Bearer'})
    return await call_next(request)

@app.exception_handler(ConflictError)
async def conflict(_,exc):return JSONResponse({'detail':'Conflicto con canon','problems':exc.problems},status_code=409)
@app.exception_handler(KeyError)
async def missing(_,exc):return JSONResponse({'detail':'Not found'},status_code=404)
@app.exception_handler(ValueError)
async def invalid(_,exc):return JSONResponse({'detail':str(exc)},status_code=422)

def use_store(request,callback):
    subject=request.state.subject
    db=Store(database_path(subject))
    try:return callback(db,subject)
    finally:db.close()

@app.get('/health')
def health():return {'ok':True,'version':'0.3.0'}
@app.get('/me')
def me(request:Request):return {'subject':request.state.subject,'authenticated':True}
@app.get('/novels')
def novels(request:Request):return use_store(request,lambda db,owner:db.novels(owner))
@app.post('/novels')
def novel(data:NovelIn,request:Request):return use_store(request,lambda db,owner:db.create_novel(data.title,owner,data.description))
@app.get('/novels/{novel_id}/entities')
def entities(novel_id:str,request:Request,kind:str|None=None):return use_store(request,lambda db,owner:db.entities(novel_id,owner,kind))
@app.post('/novels/{novel_id}/entities')
def entity(novel_id:str,data:EntityIn,request:Request):return use_store(request,lambda db,owner:{'entity_id':db.add_entity(novel_id,owner,**data.model_dump())})
@app.post('/novels/{novel_id}/claims')
def claim(novel_id:str,data:ClaimIn,request:Request):return use_store(request,lambda db,owner:{'claim_id':db.add_claim(novel_id,owner,**data.model_dump())})
@app.get('/novels/{novel_id}/entities/{entity_id}/claims')
def claims(novel_id:str,entity_id:str,request:Request,branch_id:str|None=None):return use_store(request,lambda db,owner:db.claims(novel_id,owner,entity_id,branch_id))
@app.post('/novels/{novel_id}/claims/{claim_id}/approve')
def approve(novel_id:str,claim_id:str,data:ApprovalIn,request:Request):
    # Confirmation MUST come from the user-facing UI/tool flow; server logs decision.
    return use_store(request,lambda db,owner:db.approve_claim(novel_id,owner,claim_id,actor=owner,reason=data.reason))
@app.post('/novels/{novel_id}/branches')
def branch(novel_id:str,data:BranchIn,request:Request):return use_store(request,lambda db,owner:{'branch_id':db.branch(novel_id,owner,**data.model_dump())})
@app.post('/novels/{novel_id}/timeline')
def add_time(novel_id:str,data:TimeIn,request:Request):return use_store(request,lambda db,owner:{'event_time_id':db.add_event_time(novel_id,owner,**data.model_dump())})
@app.get('/novels/{novel_id}/timeline/{branch_id}')
def timeline(novel_id:str,branch_id:str,request:Request):return use_store(request,lambda db,owner:db.timeline(novel_id,owner,branch_id))
@app.get('/novels/{novel_id}/audit/{branch_id}')
def audit(novel_id:str,branch_id:str,request:Request,latest_scene_order:int|None=None):return use_store(request,lambda db,owner:db.audit(novel_id,owner,branch_id,latest_scene_order))
@app.get('/novels/{novel_id}/export')
def export(novel_id:str,request:Request):return use_store(request,lambda db,owner:db.export_novel(novel_id,owner))
