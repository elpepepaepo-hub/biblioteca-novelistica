"""Authenticated remote MCP entry point; run with: biblioteca-mcp-remote."""
import os
from pathlib import Path
from urllib.parse import urlparse
from mcp.server.fastmcp import FastMCP
from mcp.server.auth.settings import AuthSettings
from mcp.server.auth.provider import AccessToken, TokenVerifier
from mcp.server.auth.middleware.auth_context import get_access_token
from pydantic import AnyHttpUrl
from . import remote
from .core import Store

class JWTTokenVerifier(TokenVerifier):
    async def verify_token(self, token: str) -> AccessToken | None:
        try:
            subject = remote.verify_token(token)
        except Exception:
            return None
        return AccessToken(token=token, client_id='oidc-user', scopes=['biblioteca:read', 'biblioteca:write'], expires_at=None, resource_owner=subject)

def _owner():
    access = get_access_token()
    if access is None:
        raise PermissionError('OAuth login required')
    # Do not trust client-provided IDs; derive identity from verified JWT.
    return remote.verify_token(access.token)

def _run(callback):
    owner = _owner()
    store = Store(remote.database_path(owner))
    try:
        return callback(store, owner)
    finally:
        store.close()

def build_server():
    base = os.environ['BIBLIOTECA_PUBLIC_URL'].rstrip('/')
    if not base.startswith('https://'):
        raise RuntimeError('Public MCP endpoint must use HTTPS')
    if not (remote.ISSUER.startswith('https://') and remote.AUDIENCE and remote.JWKS_URL.startswith('https://')):
        raise RuntimeError('Configure OAuth issuer, audience and JWKS')
    remote.DATA_DIR.mkdir(parents=True, exist_ok=True, mode=0o700)
    mcp = FastMCP('Biblioteca Novelística', host='0.0.0.0', port=int(os.getenv('PORT','8000')),
        stateless_http=True, json_response=True,
        auth=AuthSettings(issuer_url=AnyHttpUrl(remote.ISSUER), resource_server_url=AnyHttpUrl(base+'/mcp'), required_scopes=[]),
        token_verifier=JWTTokenVerifier())

    @mcp.tool(description='List the authenticated writer novels; never accepts a user ID.')
    def list_novels() -> list[dict]:
        return _run(lambda db,owner: db.novels(owner))

    @mcp.tool(description='Create a novel owned by the signed-in writer.')
    def create_novel(title: str, description: str='') -> dict:
        return _run(lambda db,owner: db.create_novel(title,owner,description))

    @mcp.tool(description='List entities in one owned novel. Kind may be personaje, lugar, suceso, regla, etc.')
    def list_entities(novel_id: str, kind: str | None=None) -> list[dict]:
        return _run(lambda db,owner: db.entities(novel_id,owner,kind))

    @mcp.tool(description='Create an entity in an owned novel. Does not approve any claims.')
    def create_entity(novel_id: str, kind: str, name: str, description: str='') -> dict:
        return _run(lambda db,owner: {'entity_id':db.add_entity(novel_id,owner,kind,name,description)})

    @mcp.tool(description='List recorded claims for an entity and optionally a branch.')
    def list_claims(novel_id: str, entity_id: str, branch_id: str | None=None) -> list[dict]:
        return _run(lambda db,owner: db.claims(novel_id,owner,entity_id,branch_id))

    @mcp.tool(description='Record a PROPOSAL about an entity, never silently canonize it.')
    def propose_claim(novel_id: str, entity_id: str, branch_id: str, property: str, value: str,
                      chapter: str | None=None, scene_id: str | None=None,
                      document_id: str | None=None, source_version: str | None=None,
                      valid_from: int | None=None, valid_to: int | None=None) -> dict:
        return _run(lambda db,owner: {'claim_id':db.add_claim(novel_id,owner,entity_id=entity_id,
            branch_id=branch_id,property=property,value=value,status='propuesta',chapter=chapter,
            scene_id=scene_id,document_id=document_id,source_version=source_version,
            valid_from=valid_from,valid_to=valid_to)})

    @mcp.tool(description='Approve one proposal as canon. CONSEQUENT WRITE: request explicit writer confirmation before calling.')
    def approve_claim(novel_id: str, claim_id: str, reason: str, writer_confirmed: bool=False) -> dict:
        if not writer_confirmed:
            return {'approved':False,'reason':'The writer must explicitly confirm this specific canon change.'}
        return _run(lambda db,owner: db.approve_claim(novel_id,owner,claim_id,actor=owner,reason=reason))

    @mcp.tool(description='Audit contradictions and subplot continuity for one owned novel branch.')
    def audit_branch(novel_id: str, branch_id: str) -> dict:
        return _run(lambda db,owner: db.audit(novel_id,owner,branch_id,None))

    @mcp.tool(description='Read chronology for one owned novel branch.')
    def read_timeline(novel_id: str, branch_id: str) -> list[dict]:
        return _run(lambda db,owner: db.timeline(novel_id,owner,branch_id))

    return mcp

def main():
    build_server().run(transport='streamable-http')

if __name__ == '__main__':
    main()
