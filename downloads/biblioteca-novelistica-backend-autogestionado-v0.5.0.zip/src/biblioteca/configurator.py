"""Generate safe provider configuration templates; never accept credentials on CLI."""
import argparse
import json
from pathlib import Path
from urllib.parse import urlparse
HOSTS = {
 'render': {'mode':'docker','note':'Deploy Docker service; attach persistent disk; configure HTTPS domain.'},
 'railway': {'mode':'docker','note':'Deploy Docker service; mount persistent volume; configure HTTPS domain.'},
 'fly': {'mode':'docker','note':'Deploy Docker image; mount persistent volume; configure HTTPS domain.'},
 'self-hosted': {'mode':'docker','note':'Use reverse proxy TLS and persistent volume; restrict admin ports.'},
}
IDENTITIES = {
 'auth0': {'note':'Create Auth0 API audience, enable Authorization Code + PKCE, configure application callback and allowed origins.'},
 'keycloak': {'note':'Create realm/client with Authorization Code + PKCE and API audience mapper; publish discovery and JWKS over HTTPS.'},
 'cognito': {'note':'Create user pool/domain and OAuth client; verify JWT audience and resource scopes with your actual Cognito setup.'},
}

def config(host, identity, public_url, issuer, audience, jwks):
    if host not in HOSTS or identity not in IDENTITIES:
        raise ValueError('Unsupported host or identity provider')
    for url in (public_url,issuer,jwks):
        p=urlparse(url)
        if p.scheme!='https' or not p.netloc or p.username or p.password:
            raise ValueError('URLs must be valid HTTPS addresses without embedded credentials')
    return {
      'host':host, 'identity':identity,
      'environment': {'BIBLIOTECA_PUBLIC_URL':public_url.rstrip('/'),
       'BIBLIOTECA_OIDC_ISSUER':issuer,'BIBLIOTECA_OIDC_AUDIENCE':audience,
       'BIBLIOTECA_OIDC_JWKS_URL':jwks,'BIBLIOTECA_DATA_DIR':'/data'},
      'mcp_endpoint':public_url.rstrip('/')+'/mcp',
      'hosting_notes':HOSTS[host]['note'], 'identity_notes':IDENTITIES[identity]['note'],
      'requires_deployment_and_oauth_registration':True
    }

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--host',choices=HOSTS,required=True)
    p.add_argument('--identity',choices=IDENTITIES,required=True)
    p.add_argument('--public-url',required=True)
    p.add_argument('--issuer',required=True)
    p.add_argument('--audience',required=True)
    p.add_argument('--jwks',required=True)
    p.add_argument('--output',default='connection-plan.json')
    a=p.parse_args()
    Path(a.output).write_text(json.dumps(config(a.host,a.identity,a.public_url,a.issuer,a.audience,a.jwks),indent=2),encoding='utf8')
    print('Wrote connection plan (no credentials):',a.output)
if __name__=='__main__':main()
