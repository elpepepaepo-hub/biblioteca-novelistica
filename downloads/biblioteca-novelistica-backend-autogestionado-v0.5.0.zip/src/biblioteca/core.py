"""Structured narrative memory. SQLite local-first, strict canon acceptance."""
import json
import sqlite3
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

STATUSES = {"canon", "propuesta", "alternativa", "contradiccion"}
KINDS = {"personaje", "lugar", "acontecimiento", "regla", "organizacion", "objeto", "subtrama"}
SEVERITIES = {"grave", "importante", "menor"}

def now():
    return datetime.now(timezone.utc).isoformat()

def ident():
    return str(uuid.uuid4())

SCHEMA = """
PRAGMA foreign_keys=ON;
CREATE TABLE IF NOT EXISTS novel (
 id TEXT PRIMARY KEY, title TEXT NOT NULL, description TEXT NOT NULL DEFAULT '',
 owner TEXT NOT NULL, created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS branch (
 id TEXT PRIMARY KEY, novel_id TEXT NOT NULL REFERENCES novel(id) ON DELETE CASCADE,
 name TEXT NOT NULL, parent_id TEXT REFERENCES branch(id), is_primary INTEGER NOT NULL DEFAULT 0,
 created_at TEXT NOT NULL, UNIQUE(novel_id,name));
CREATE TABLE IF NOT EXISTS document (
 id TEXT PRIMARY KEY, novel_id TEXT NOT NULL REFERENCES novel(id) ON DELETE CASCADE,
 title TEXT NOT NULL, revision TEXT NOT NULL, created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS scene (
 id TEXT PRIMARY KEY, novel_id TEXT NOT NULL REFERENCES novel(id) ON DELETE CASCADE,
 document_id TEXT REFERENCES document(id), chapter TEXT, title TEXT NOT NULL,
 ordering INTEGER, created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS entity (
 id TEXT PRIMARY KEY, novel_id TEXT NOT NULL REFERENCES novel(id) ON DELETE CASCADE,
 kind TEXT NOT NULL, name TEXT NOT NULL, description TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL,
 UNIQUE(novel_id,kind,name));
CREATE TABLE IF NOT EXISTS entity_relation (
 id TEXT PRIMARY KEY, novel_id TEXT NOT NULL REFERENCES novel(id) ON DELETE CASCADE,
 subject_id TEXT NOT NULL REFERENCES entity(id) ON DELETE CASCADE,
 predicate TEXT NOT NULL, object_id TEXT NOT NULL REFERENCES entity(id) ON DELETE CASCADE,
 branch_id TEXT NOT NULL REFERENCES branch(id), status TEXT NOT NULL,
 created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS claim (
 id TEXT PRIMARY KEY, novel_id TEXT NOT NULL REFERENCES novel(id) ON DELETE CASCADE,
 entity_id TEXT NOT NULL REFERENCES entity(id) ON DELETE CASCADE,
 branch_id TEXT NOT NULL REFERENCES branch(id), property TEXT NOT NULL, value_json TEXT NOT NULL,
 status TEXT NOT NULL, valid_from INTEGER, valid_to INTEGER,
 chapter TEXT, scene_id TEXT REFERENCES scene(id), document_id TEXT REFERENCES document(id),
 source_version TEXT, registered_at TEXT NOT NULL, supersedes TEXT REFERENCES claim(id),
 author_note TEXT NOT NULL DEFAULT '', CHECK(valid_from IS NULL OR valid_to IS NULL OR valid_from<=valid_to));
CREATE TABLE IF NOT EXISTS canon_decision (
 id TEXT PRIMARY KEY, novel_id TEXT NOT NULL REFERENCES novel(id) ON DELETE CASCADE,
 claim_id TEXT NOT NULL REFERENCES claim(id), action TEXT NOT NULL,
 actor TEXT NOT NULL, reason TEXT NOT NULL, created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS event_time (
 id TEXT PRIMARY KEY, novel_id TEXT NOT NULL REFERENCES novel(id) ON DELETE CASCADE,
 entity_id TEXT NOT NULL REFERENCES entity(id) ON DELETE CASCADE,
 branch_id TEXT NOT NULL REFERENCES branch(id),
 start_tick INTEGER, end_tick INTEGER, calendar TEXT NOT NULL DEFAULT 'personalizado',
 narrative_order INTEGER, chapter TEXT, chronology_mode TEXT NOT NULL DEFAULT 'lineal',
 created_at TEXT NOT NULL, CHECK(start_tick IS NULL OR end_tick IS NULL OR start_tick<=end_tick));
CREATE TABLE IF NOT EXISTS subplot (
 id TEXT PRIMARY KEY, novel_id TEXT NOT NULL REFERENCES novel(id) ON DELETE CASCADE,
 entity_id TEXT NOT NULL REFERENCES entity(id) ON DELETE CASCADE,
 branch_id TEXT NOT NULL REFERENCES branch(id), last_scene_order INTEGER,
 state TEXT NOT NULL, notes TEXT NOT NULL DEFAULT '', updated_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS scene_version (
 id TEXT PRIMARY KEY, novel_id TEXT NOT NULL REFERENCES novel(id) ON DELETE CASCADE,
 scene_id TEXT NOT NULL REFERENCES scene(id) ON DELETE CASCADE,
 branch_id TEXT NOT NULL REFERENCES branch(id), version TEXT NOT NULL, body TEXT NOT NULL,
 created_at TEXT NOT NULL, UNIQUE(scene_id,branch_id,version));
CREATE TABLE IF NOT EXISTS issue (
 id TEXT PRIMARY KEY, novel_id TEXT NOT NULL REFERENCES novel(id) ON DELETE CASCADE,
 branch_id TEXT REFERENCES branch(id), severity TEXT NOT NULL,
 code TEXT NOT NULL, description TEXT NOT NULL, evidence_json TEXT NOT NULL,
 status TEXT NOT NULL DEFAULT 'abierta', created_at TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS claim_lookup ON claim(novel_id,entity_id,branch_id,property,status);
CREATE INDEX IF NOT EXISTS time_lookup ON event_time(novel_id,branch_id,start_tick);
"""

class ConflictError(ValueError):
    def __init__(self, problems):
        self.problems = problems
        super().__init__("Contradicción con el canon: " + json.dumps(problems, ensure_ascii=False))

class Store:
    def __init__(self, filename: str | Path = ':memory:'):
        self.db = sqlite3.connect(str(filename))
        self.db.row_factory = sqlite3.Row
        self.db.executescript(SCHEMA)
        self.db.commit()

    def close(self):
        self.db.close()

    def _one(self, sql, args=()):
        row = self.db.execute(sql, args).fetchone()
        if row is None:
            raise KeyError('Registro inexistente o ajeno al proyecto')
        return dict(row)

    def _all(self, sql, args=()):
        return [dict(r) for r in self.db.execute(sql,args).fetchall()]

    def _insert(self, table, **kv):
        keys=list(kv)
        self.db.execute(f"INSERT INTO {table} ({','.join(keys)}) VALUES ({','.join('?' for _ in keys)})",list(kv.values()))
        self.db.commit()
        return kv['id']

    def _scope(self, novel_id, owner):
        return self._one('SELECT * FROM novel WHERE id=? AND owner=?',(novel_id,owner))

    def _belongs(self, table, record_id, novel_id):
        return self._one(f'SELECT * FROM {table} WHERE id=? AND novel_id=?',(record_id,novel_id))

    def create_novel(self,title,owner='local',description=''):
        nid=ident()
        self._insert('novel',id=nid,title=title,description=description,owner=owner,created_at=now())
        bid=self._insert('branch',id=ident(),novel_id=nid,name='principal',parent_id=None,is_primary=1,created_at=now())
        return {'novel_id':nid,'branch_id':bid}

    def novels(self,owner='local'):
        return self._all('SELECT * FROM novel WHERE owner=? ORDER BY created_at',(owner,))

    def branch(self,novel_id,owner,name,parent_id):
        self._scope(novel_id,owner)
        self._belongs('branch',parent_id,novel_id)
        return self._insert('branch',id=ident(),novel_id=novel_id,name=name,parent_id=parent_id,is_primary=0,created_at=now())

    def add_entity(self,novel_id,owner,kind,name,description=''):
        self._scope(novel_id,owner)
        if kind not in KINDS: raise ValueError('Tipo no admitido')
        return self._insert('entity',id=ident(),novel_id=novel_id,kind=kind,name=name,description=description,created_at=now())

    def entities(self,novel_id,owner,kind=None):
        self._scope(novel_id,owner)
        if kind:return self._all('SELECT * FROM entity WHERE novel_id=? AND kind=? ORDER BY name',(novel_id,kind))
        return self._all('SELECT * FROM entity WHERE novel_id=? ORDER BY kind,name',(novel_id,))

    def add_claim(self,novel_id,owner,entity_id,branch_id,property,value,status='propuesta',valid_from=None,valid_to=None,
                  chapter=None,scene_id=None,document_id=None,source_version=None,author_note=''):
        self._scope(novel_id,owner)
        self._belongs('entity',entity_id,novel_id);self._belongs('branch',branch_id,novel_id)
        if scene_id:self._belongs('scene',scene_id,novel_id)
        if document_id:self._belongs('document',document_id,novel_id)
        if status not in STATUSES:raise ValueError('Estado inválido')
        if valid_from is not None and valid_to is not None and valid_from>valid_to: raise ValueError('Intervalo inválido')
        # New claims are never implicitly authorized canon; even a requested canon becomes a proposal.
        if status == 'canon': raise ValueError('Para canon, cree propuesta y apruebe con approve_claim')
        cid=ident()
        self._insert('claim',id=cid,novel_id=novel_id,entity_id=entity_id,branch_id=branch_id,property=property,
            value_json=json.dumps(value,ensure_ascii=False),status=status,valid_from=valid_from,valid_to=valid_to,
            chapter=chapter,scene_id=scene_id,document_id=document_id,source_version=source_version,
            registered_at=now(),supersedes=None,author_note=author_note)
        return cid

    @staticmethod
    def _overlap(a,b):
        low1=a['valid_from'] if a['valid_from'] is not None else float('-inf')
        high1=a['valid_to'] if a['valid_to'] is not None else float('inf')
        low2=b['valid_from'] if b['valid_from'] is not None else float('-inf')
        high2=b['valid_to'] if b['valid_to'] is not None else float('inf')
        return low1<=high2 and low2<=high1

    def conflicts_for(self,claim):
        if claim['status']=='alternativa':return []
        candidates=self._all('SELECT * FROM claim WHERE novel_id=? AND entity_id=? AND branch_id=? AND property=? AND status="canon" AND id!=?',
            (claim['novel_id'],claim['entity_id'],claim['branch_id'],claim['property'],claim['id']))
        return [{'code':'CANON_VALUE_CONFLICT','severity':'grave','existing_claim_id':c['id'],'candidate_claim_id':claim['id']}
                for c in candidates if self._overlap(c,claim) and json.loads(c['value_json'])!=json.loads(claim['value_json'])]

    def approve_claim(self,novel_id,owner,claim_id,actor,reason='Confirmado por el autor'):
        self._scope(novel_id,owner)
        claim=self._belongs('claim',claim_id,novel_id)
        if claim['status']!='propuesta': raise ValueError('Solo una propuesta puede aprobarse')
        problems=self.conflicts_for(claim)
        if problems:
            for problem in problems:
                self.record_issue(novel_id,owner,claim['branch_id'],'grave',problem['code'],'Conflicto al intentar aprobar canon',problem)
            raise ConflictError(problems)
        self.db.execute('UPDATE claim SET status="canon" WHERE id=?',(claim_id,))
        self._insert('canon_decision',id=ident(),novel_id=novel_id,claim_id=claim_id,action='aprobada',actor=actor,reason=reason,created_at=now())
        return self._belongs('claim',claim_id,novel_id)

    def claims(self,novel_id,owner,entity_id,branch_id=None):
        self._scope(novel_id,owner);self._belongs('entity',entity_id,novel_id)
        sql='SELECT * FROM claim WHERE novel_id=? AND entity_id=?';args=[novel_id,entity_id]
        if branch_id:self._belongs('branch',branch_id,novel_id);sql+=' AND branch_id=?';args.append(branch_id)
        return [{**row,'value':json.loads(row.pop('value_json'))} for row in self._all(sql+' ORDER BY registered_at,id',args)]

    def add_relation(self,novel_id,owner,subject_id,predicate,object_id,branch_id,status='propuesta'):
        self._scope(novel_id,owner)
        for eid in (subject_id,object_id):self._belongs('entity',eid,novel_id)
        self._belongs('branch',branch_id,novel_id)
        if status not in STATUSES:raise ValueError('Estado inválido')
        if status=='canon':raise ValueError('Relación requiere aprobación explícita posterior')
        return self._insert('entity_relation',id=ident(),novel_id=novel_id,subject_id=subject_id,predicate=predicate,object_id=object_id,
                           branch_id=branch_id,status=status,created_at=now())

    def add_document(self,novel_id,owner,title,revision='1'):
        self._scope(novel_id,owner)
        return self._insert('document',id=ident(),novel_id=novel_id,title=title,revision=revision,created_at=now())

    def add_scene(self,novel_id,owner,title,chapter=None,document_id=None,ordering=None):
        self._scope(novel_id,owner)
        if document_id:self._belongs('document',document_id,novel_id)
        return self._insert('scene',id=ident(),novel_id=novel_id,title=title,chapter=chapter,document_id=document_id,ordering=ordering,created_at=now())

    def add_scene_version(self,novel_id,owner,scene_id,branch_id,version,body):
        self._scope(novel_id,owner)
        self._belongs('scene',scene_id,novel_id);self._belongs('branch',branch_id,novel_id)
        return self._insert('scene_version',id=ident(),novel_id=novel_id,scene_id=scene_id,branch_id=branch_id,version=version,body=body,created_at=now())

    def add_event_time(self,novel_id,owner,entity_id,branch_id,start_tick=None,end_tick=None,calendar='personalizado',narrative_order=None,chapter=None,chronology_mode='lineal'):
        self._scope(novel_id,owner);ent=self._belongs('entity',entity_id,novel_id);self._belongs('branch',branch_id,novel_id)
        if ent['kind']!='acontecimiento':raise ValueError('La cronología requiere un acontecimiento')
        if start_tick is not None and end_tick is not None and start_tick>end_tick:raise ValueError('Evento termina antes de empezar')
        return self._insert('event_time',id=ident(),novel_id=novel_id,entity_id=entity_id,branch_id=branch_id,
            start_tick=start_tick,end_tick=end_tick,calendar=calendar,narrative_order=narrative_order,chapter=chapter,
            chronology_mode=chronology_mode,created_at=now())

    def timeline(self,novel_id,owner,branch_id):
        self._scope(novel_id,owner);self._belongs('branch',branch_id,novel_id)
        return self._all('SELECT t.*,e.name FROM event_time t JOIN entity e ON e.id=t.entity_id WHERE t.novel_id=? AND t.branch_id=? ORDER BY t.start_tick,t.narrative_order',(novel_id,branch_id))

    def set_subplot(self,novel_id,owner,entity_id,branch_id,state,last_scene_order=None,notes=''):
        self._scope(novel_id,owner);ent=self._belongs('entity',entity_id,novel_id);self._belongs('branch',branch_id,novel_id)
        if ent['kind']!='subtrama':raise ValueError('Se requiere entidad subtrama')
        return self._insert('subplot',id=ident(),novel_id=novel_id,entity_id=entity_id,branch_id=branch_id,
            state=state,last_scene_order=last_scene_order,notes=notes,updated_at=now())

    def record_issue(self,novel_id,owner,branch_id,severity,code,description,evidence):
        self._scope(novel_id,owner)
        if branch_id:self._belongs('branch',branch_id,novel_id)
        if severity not in SEVERITIES:raise ValueError('Gravedad inválida')
        return self._insert('issue',id=ident(),novel_id=novel_id,branch_id=branch_id,severity=severity,code=code,
            description=description,evidence_json=json.dumps(evidence,ensure_ascii=False),created_at=now(),status='abierta')

    def audit(self,novel_id,owner,branch_id,latest_scene_order=None,abandonment_threshold=5):
        self._scope(novel_id,owner);self._belongs('branch',branch_id,novel_id)
        findings=[]
        claims=self._all('SELECT * FROM claim WHERE novel_id=? AND branch_id=? AND status="canon"',(novel_id,branch_id))
        for i,c in enumerate(claims):
            for d in claims[i+1:]:
                if c['entity_id']==d['entity_id'] and c['property']==d['property'] and self._overlap(c,d) and c['value_json']!=d['value_json']:
                    findings.append({'severity':'grave','code':'CANON_VALUE_CONFLICT','evidence':[c['id'],d['id']]})
        if latest_scene_order is not None:
            for sub in self._all('SELECT * FROM subplot WHERE novel_id=? AND branch_id=?',(novel_id,branch_id)):
                if sub['state']=='abierta' and sub['last_scene_order'] is not None and latest_scene_order-sub['last_scene_order']>=abandonment_threshold:
                    findings.append({'severity':'importante','code':'SUBPLOT_DORMANT','evidence':[sub['entity_id']]})
        # All narrative-order differences are allowed for nonlinear fiction; chronology uses story time.
        return findings

    def export_novel(self,novel_id,owner):
        self._scope(novel_id,owner)
        result={'format':'biblioteca-novelistica-export-v1','exported_at':now(),'tables':{}}
        for table in ['novel','branch','document','scene','entity','entity_relation','claim','canon_decision','event_time','subplot','scene_version','issue']:
            result['tables'][table]=self._all(f'SELECT * FROM {table} WHERE '+('id=?' if table=='novel' else 'novel_id=?'),(novel_id,))
        return result

    def import_novel(self,payload,owner='local'):
        if payload.get('format')!='biblioteca-novelistica-export-v1':raise ValueError('Formato incompatible')
        tables=payload['tables']
        if len(tables.get('novel',[]))!=1:raise ValueError('Debe contener una novela')
        new_id=ident();old_id=tables['novel'][0]['id']
        maps={}
        for t in ['branch','document','scene','entity','entity_relation','claim','canon_decision','event_time','subplot','scene_version','issue']:
            maps[t]={row['id']:ident() for row in tables.get(t,[])}
        rewrites={'branch':{'parent_id':'branch'},'scene':{'document_id':'document'},'entity_relation':{'subject_id':'entity','object_id':'entity','branch_id':'branch'},
                  'claim':{'entity_id':'entity','branch_id':'branch','scene_id':'scene','document_id':'document','supersedes':'claim'},
                  'canon_decision':{'claim_id':'claim'},'event_time':{'entity_id':'entity','branch_id':'branch'},
                  'subplot':{'entity_id':'entity','branch_id':'branch'},'scene_version':{'scene_id':'scene','branch_id':'branch'},'issue':{'branch_id':'branch'}}
        self.db.execute('BEGIN')
        try:
            original=dict(tables['novel'][0]);original.update(id=new_id,owner=owner,created_at=now())
            self._raw_insert('novel',original)
            for t in ['branch','document','scene','entity','entity_relation','claim','canon_decision','event_time','subplot','scene_version','issue']:
                for original in tables.get(t,[]):
                    r=dict(original);r['id']=maps[t][original['id']];r['novel_id']=new_id
                    for field,target in rewrites.get(t,{}).items():
                        if r.get(field) is not None:r[field]=maps[target][r[field]]
                    self._raw_insert(t,r)
            self.db.commit()
        except Exception:
            self.db.rollback();raise
        return {'old_novel_id':old_id,'novel_id':new_id}

    def _raw_insert(self,table,values):
        fields=list(values)
        self.db.execute(f"INSERT INTO {table} ({','.join(fields)}) VALUES ({','.join('?' for _ in fields)})",list(values.values()))
