"""Biblioteca Novelística — memory and continuity engine."""
__version__ = "0.2.0"
