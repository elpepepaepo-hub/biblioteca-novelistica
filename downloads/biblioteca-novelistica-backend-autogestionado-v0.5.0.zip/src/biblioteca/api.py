"""Optional local HTTP API; NOT a hosted service nor an OAuth server."""
import os
import secrets
from contextlib import asynccontextmanager
from pathlib import Path
from fastapi import FastAPI, Header, HTTPException, Request
from pydantic import BaseModel, Field
from .core import Store, ConflictError

DB_PATH = os.getenv('BIBLIOTECA_DB_PATH','biblioteca.sqlite3')
AUTH_MODE = os.getenv('BIBLIOTECA_AUTH','token')
AUTH_TOKEN = os.getenv('BIBLIOTECA_TOKEN','')
if AUTH_MODE not in ('token','off'):
    raise RuntimeError('BIBLIOTECA_AUTH debe ser token u off')
if AUTH_MODE == 'token' and len(AUTH_TOKEN)<32:
    raise RuntimeError('BIBLIOTECA_TOKEN debe tener 32 caracteres o más; ejecute python -m secrets para generar uno')
if AUTH_MODE == 'off' and os.getenv('BIBLIOTECA_BIND','127.0.0.1') not in ('127.0.0.1','localhost','::1'):
    raise RuntimeError('La autenticación desactivada solo es admisible en loopback')

@asynccontextmanager
async def lifespan(app:FastAPI):
    app.state.store=Store(DB_PATH)
    yield
    app.state.store.close()

app=FastAPI(title='Biblioteca Novelística local API',version='0.2.0',lifespan=lifespan)

@app.middleware('http')
async def auth(request:Request,call_next):
    # The disabled option is for LOCAL DEMOS ONLY. Do not place behind a public reverse proxy.
    if AUTH_MODE=='off':
        if not request.client or request.client.host not in ('127.0.0.1','::1','testclient'):
            raise HTTPException(403,'Modo sin autenticación limitado a localhost')
    elif request.url.path != '/health':
        supplied=request.headers.get('authorization','')
        if not secrets.compare_digest(supplied,'Bearer '+AUTH_TOKEN):
            from fastapi.responses import JSONResponse
            return JSONResponse({'detail':'Acceso no autorizado'},status_code=401)
    return await call_next(request)

class NovelIn(BaseModel):
    title:str=Field(min_length=1)
    description:str=''
class EntityIn(BaseModel):
    kind:str
    name:str=Field(min_length=1)
    description:str=''
class ClaimIn(BaseModel):
    entity_id:str
    branch_id:str
    property:str=Field(min_length=1)
    value:object
    status:str='propuesta'
    valid_from:int|None=None
    valid_to:int|None=None
    chapter:str|None=None
    scene_id:str|None=None
    document_id:str|None=None
    source_version:str|None=None
    author_note:str=''
class ApprovalIn(BaseModel):
    actor:str=Field(min_length=1)
    reason:str='Confirmado expresamente por el autor'
class BranchIn(BaseModel):
    name:str=Field(min_length=1)
    parent_id:str
class TimeIn(BaseModel):
    entity_id:str
    branch_id:str
    start_tick:int|None=None
    end_tick:int|None=None
    calendar:str='personalizado'
    narrative_order:int|None=None
    chapter:str|None=None
    chronology_mode:str='lineal'

@app.exception_handler(ConflictError)
async def conflict_handler(_,exc:ConflictError):
    from fastapi.responses import JSONResponse
    return JSONResponse({'detail': 'Conflicto con el canon','problems':exc.problems},status_code=409)
@app.exception_handler(KeyError)
async def key_handler(_,exc):
    from fastapi.responses import JSONResponse
    return JSONResponse({'detail':str(exc)},status_code=404)
@app.exception_handler(ValueError)
async def value_handler(_,exc):
    from fastapi.responses import JSONResponse
    return JSONResponse({'detail':str(exc)},status_code=422)

def store(request:Request):return request.app.state.store

@app.get('/health')
async def health():return {'ok':True,'version':'0.2.0','authentication':AUTH_MODE}
@app.post('/novels')
async def create_novel(data:NovelIn,request:Request):return store(request).create_novel(data.title,description=data.description)
@app.get('/novels')
async def list_novels(request:Request):return store(request).novels()
@app.post('/novels/{novel_id}/entities')
async def create_entity(novel_id:str,data:EntityIn,request:Request):return {'entity_id':store(request).add_entity(novel_id,'local',**data.model_dump())}
@app.get('/novels/{novel_id}/entities')
async def list_entities(novel_id:str,request:Request,kind:str|None=None):return store(request).entities(novel_id,'local',kind)
@app.post('/novels/{novel_id}/claims')
async def create_claim(novel_id:str,data:ClaimIn,request:Request):return {'claim_id':store(request).add_claim(novel_id,'local',**data.model_dump())}
@app.get('/novels/{novel_id}/entities/{entity_id}/claims')
async def list_claims(novel_id:str,entity_id:str,request:Request,branch_id:str|None=None):return store(request).claims(novel_id,'local',entity_id,branch_id)
@app.post('/novels/{novel_id}/claims/{claim_id}/approve')
async def approve(novel_id:str,claim_id:str,data:ApprovalIn,request:Request):return store(request).approve_claim(novel_id,'local',claim_id,**data.model_dump())
@app.post('/novels/{novel_id}/branches')
async def branch(novel_id:str,data:BranchIn,request:Request):return {'branch_id':store(request).branch(novel_id,'local',**data.model_dump())}
@app.post('/novels/{novel_id}/timeline')
async def add_event(novel_id:str,data:TimeIn,request:Request):return {'event_time_id':store(request).add_event_time(novel_id,'local',**data.model_dump())}
@app.get('/novels/{novel_id}/timeline/{branch_id}')
async def timeline(novel_id:str,branch_id:str,request:Request):return store(request).timeline(novel_id,'local',branch_id)
@app.get('/novels/{novel_id}/audit/{branch_id}')
async def audit(novel_id:str,branch_id:str,request:Request,latest_scene_order:int|None=None):return store(request).audit(novel_id,'local',branch_id,latest_scene_order)
@app.get('/novels/{novel_id}/export')
async def export(novel_id:str,request:Request):return store(request).export_novel(novel_id,'local')
