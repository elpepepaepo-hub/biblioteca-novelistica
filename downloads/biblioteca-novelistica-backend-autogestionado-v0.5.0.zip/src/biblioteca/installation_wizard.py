"""Guided self-hosted setup: no credentials collected, no deployment performed."""
from __future__ import annotations
import argparse, json, re
from pathlib import Path
from urllib.parse import urlparse

HOSTS = {
    'local': 'Single-computer, loopback only (not remotely reachable from ChatGPT)',
    'render': 'Render Docker web service with persistent disk (check paid disk pricing)',
    'railway': 'Railway Docker service with persistent volume',
    'fly': 'Fly.io machine with mounted volume',
    'self-hosted': 'Own VPS running Docker behind HTTPS reverse proxy',
}
DATABASES = {'sqlite': 'SQLite file inside persistent volume', 'postgres': 'PostgreSQL (future adapter, not available in this build)'}
AUTH = {'off-local': 'Off, loopback only', 'token-local': 'Local private token', 'oauth': 'OIDC/OAuth remote login'}
IDENTITIES = {'auth0': 'Auth0', 'keycloak': 'Keycloak', 'cognito': 'Amazon Cognito'}

def validate(host: str, database: str, auth: str, identity: str|None = None,
             public_url: str|None = None, bind: str='127.0.0.1') -> dict:
    if host not in HOSTS: raise ValueError('Alojamiento no admitido')
    if database not in DATABASES: raise ValueError('Base de datos no admitida')
    if auth not in AUTH: raise ValueError('Método de autenticación no admitido')
    if database == 'postgres':
        raise ValueError('PostgreSQL requiere un adaptador no implementado. Use SQLite con volumen persistente.')
    if host == 'local':
        if auth not in ('off-local','token-local'):
            raise ValueError('El modo local no admite OAuth remoto en esta versión')
        if bind not in ('localhost','127.0.0.1','::1'):
            raise ValueError('Una instalación local debe escuchar exclusivamente en loopback')
        if public_url: raise ValueError('Instalación local no admite URL pública')
        if identity: raise ValueError('No se necesita proveedor de identidad en modo local')
    else:
        if auth != 'oauth':
            raise ValueError('BLOQUEADO: ningún servidor público puede funcionar sin OAuth')
        if identity not in IDENTITIES: raise ValueError('Seleccione proveedor OIDC compatible')
        if public_url:
            u=urlparse(public_url)
            if u.scheme!='https' or not u.netloc or u.username or u.password or u.query or u.fragment or u.path not in ('','/'):
                raise ValueError('URL pública debe ser HTTPS, sin rutas, secretos ni parámetros')
            if u.hostname in ('localhost','127.0.0.1','::1') or u.hostname.endswith('.example'):
                raise ValueError('Proporcione un dominio HTTPS real, no un ejemplo')
    return {'mode':'sencillo' if host=='local' else 'persistente', 'host':host,
            'database':database,'auth':auth,'identity':identity if host!='local' else None,
            'public_url':public_url.rstrip('/') if public_url else None,
            'ready_for_chatgpt':False,
            'state':'Plantilla local: ejecútela en su equipo' if host=='local' else 'Despliegue/OAuth/HTTPS pendientes de validación'}

def _template(host: str) -> tuple[str,str]:
    if host=='render':
        return 'render.yaml', """services:\n  - type: web\n    name: biblioteca-novelistica\n    runtime: docker\n    dockerfilePath: ./Dockerfile.mcp\n    envVars:\n      - key: BIBLIOTECA_PUBLIC_URL\n        sync: false\n      - key: BIBLIOTECA_OIDC_ISSUER\n        sync: false\n      - key: BIBLIOTECA_OIDC_AUDIENCE\n        sync: false\n      - key: BIBLIOTECA_OIDC_JWKS_URL\n        sync: false\n      - key: BIBLIOTECA_DATA_DIR\n        value: /data\n    disk:\n      name: biblioteca-persistent-data\n      mountPath: /data\n      sizeGB: 1\n"""
    if host=='railway':
        return 'railway.toml', """[build]\nbuilder = "DOCKERFILE"\ndockerfilePath = "Dockerfile.mcp"\n\n[deploy]\nrestartPolicyType = "ON_FAILURE"\nrestartPolicyMaxRetries = 5\n# Configure all BIBLIOTECA_* variables in Railway dashboard.\n# Add persistent volume mounted at /data from the Railway dashboard.\n"""
    if host=='fly':
        return 'fly.template.toml', """# Set a unique app name before deployment. Never deploy this template unchanged.\napp = "REPLACE_WITH_YOUR_FLY_APP"\nprimary_region = "mad"\n\n[build]\ndockerfile = "Dockerfile.mcp"\n\n[env]\n  BIBLIOTECA_DATA_DIR = "/data"\n  PORT = "8000"\n\n[[mounts]]\n  source = "biblioteca_data"\n  destination = "/data"\n\n[http_service]\n  internal_port = 8000\n  force_https = true\n  auto_stop_machines = "off"\n  auto_start_machines = true\n"""
    if host=='self-hosted':
        return 'compose.self-hosted.yaml', """services:\n  biblioteca-mcp:\n    build:\n      context: .\n      dockerfile: Dockerfile.mcp\n    env_file: .env\n    ports:\n      - "127.0.0.1:8000:8000"\n    volumes:\n      - biblioteca_data:/data\n    restart: unless-stopped\nvolumes:\n  biblioteca_data:\n# Configure separate TLS reverse proxy forwarding HTTPS to 127.0.0.1:8000.\n"""
    return 'compose.local.yaml', """services:\n  biblioteca-api:\n    build:\n      context: .\n      dockerfile: Dockerfile.local\n    environment:\n      BIBLIOTECA_DB_PATH: /data/biblioteca.sqlite3\n      BIBLIOTECA_AUTH: token\n      BIBLIOTECA_TOKEN: ${BIBLIOTECA_TOKEN:?Set 32+ character private token locally}\n      BIBLIOTECA_BIND: 127.0.0.1\n    ports:\n      - "127.0.0.1:8765:8765"\n    volumes:\n      - biblioteca_data:/data\nvolumes:\n  biblioteca_data:\n# Docker uses token even on localhost. To run WITHOUT authentication, run Python directly bound to 127.0.0.1, never Docker/external.\n"""

def generate(profile: dict, output: str|Path) -> Path:
    # Revalidate manually constructed profiles; no trust in an editable plan.
    profile=validate(profile['host'],profile['database'],profile['auth'],profile.get('identity'),profile.get('public_url'),profile.get('bind','127.0.0.1'))
    dest=Path(output)
    dest.mkdir(parents=True,exist_ok=True)
    path,name=_template(profile['host'])
    (dest/path).write_text(name,encoding='utf8')
    (dest/'plan.json').write_text(json.dumps(profile,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
    if profile['host']=='local':
        (dest/'variables.example').write_text('BIBLIOTECA_AUTH=token\nBIBLIOTECA_BIND=127.0.0.1\n# Generate BIBLIOTECA_TOKEN locally: python -c \"import secrets; print(secrets.token_urlsafe(40))\"\n# Never put token in ZIP or chat.\n',encoding='utf8')
        steps='1. Run the local API on 127.0.0.1 only.\n2. This is NOT connected to ChatGPT cloud.\n3. Save/export local backups regularly.\n'
    else:
        (dest/'variables.example').write_text("""# Enter real values ONLY in your provider's protected secrets dashboard, not in ChatGPT or a ZIP.\nBIBLIOTECA_PUBLIC_URL=\nBIBLIOTECA_OIDC_ISSUER=\nBIBLIOTECA_OIDC_AUDIENCE=\nBIBLIOTECA_OIDC_JWKS_URL=\nBIBLIOTECA_DATA_DIR=/data\nPORT=8000\n""",encoding='utf8')
        steps=('1. Open your own account with the selected hosting provider; inspect pricing and persistent-disk support.\n'
               '2. Create an OAuth/OIDC app in the selected identity provider using authorization code + PKCE.\n'
               '3. Enter issuer, API audience, JWKS and actual service HTTPS URL in HOSTING SECRETS; never paste passwords here.\n'
               '4. Deploy Dockerfile.mcp, attach a persistent /data volume, configure TLS and public HTTPS domain.\n'
               '5. Check issuer and resource-server metadata, the OAuth sign-in flow and token rejection.\n'
               '6. Register the ACTUAL verified /mcp URL in ChatGPT if the account supports remote MCP connectors.\n'
               '7. Make a backup/export and test restore; apply rate limits and monitor service.\n'
               '8. Do NOT place an unverified URL in mcp.json.\n')
    (dest/'PASOS.txt').write_text(steps,encoding='utf8')
    return dest

def ask(question, choices, default):
    print('\n'+question)
    for key, desc in choices.items(): print('  '+key+' — '+desc)
    answer=input('Elección ['+default+']: ').strip() or default
    if answer not in choices: raise ValueError('Opción no admitida: '+answer)
    return answer

def main(argv=None):
    parser=argparse.ArgumentParser(description='Asistente seguro de instalación de Biblioteca Novelística')
    parser.add_argument('--mode',choices=('sencillo','persistente'))
    parser.add_argument('--host',choices=HOSTS)
    parser.add_argument('--database',default='sqlite',choices=DATABASES)
    parser.add_argument('--auth',choices=AUTH)
    parser.add_argument('--identity',choices=IDENTITIES)
    parser.add_argument('--public-url')
    parser.add_argument('--output',default='./mi-instalacion')
    args=parser.parse_args(argv)
    try:
        mode=args.mode or ask('Modo de trabajo',{'sencillo':'ChatGPT conversacional, sin servicio propio','persistente':'Mi propio servidor MCP y SQLite'},'sencillo')
        host=args.host or (('local') if mode=='sencillo' else ask('Alojamiento', {k:v for k,v in HOSTS.items() if k!='local'},'railway'))
        if mode=='sencillo' and host!='local': raise ValueError('El modo sencillo no requiere alojamiento remoto')
        if mode=='persistente' and host=='local': raise ValueError('El modo persistente remoto exige alojamiento accesible por HTTPS')
        auth=args.auth or ('off-local' if host=='local' else 'oauth')
        identity=args.identity or (ask('Proveedor de cuentas',IDENTITIES,'auth0') if host!='local' else None)
        profile=validate(host,args.database,auth,identity,args.public_url)
        generate(profile,args.output)
        print('Configuración generada (SIN credenciales): '+str(Path(args.output).resolve()))
        print('Estado: '+profile['state'])
        return 0
    except ValueError as exc:
        parser.error(str(exc))

if __name__=='__main__': raise SystemExit(main())
