"""Optional MCP connector. Requires: pip install '.[mcp]'.

Local stdio is the safe default. HTTP listens only on localhost for development.
Do NOT expose the HTTP endpoint to the internet without real OAuth, TLS, quotas,
request authorization and per-user database isolation.
"""
import argparse
import json
import os
from .core import Store


def build_server():
    try:
        from mcp.server.fastmcp import FastMCP
    except ImportError as exc:
        raise RuntimeError("Instale el extra MCP: pip install -e '.[mcp]'") from exc
    mcp = FastMCP('Biblioteca Novelística', instructions='Registro de canon de novelas. Crear propuestas y pedir confirmación humana explícita antes de aprobar.')
    db = Store(os.environ.get('BIBLIOTECA_DB_PATH','biblioteca.sqlite3'))

    @mcp.tool()
    def listar_novelas() -> list[dict]:
        """Listar novelas del propietario local."""
        return db.novels('local')

    @mcp.tool()
    def crear_novela(titulo: str, descripcion: str = '') -> dict:
        """Crear un nuevo universo y su rama principal."""
        return db.create_novel(titulo, 'local', descripcion)

    @mcp.tool()
    def crear_entidad(novela_id: str, tipo: str, nombre: str, descripcion: str = '') -> dict:
        """Crear personaje, lugar, acontecimiento, regla, organización, objeto o subtrama."""
        return {'entity_id': db.add_entity(novela_id, 'local', tipo, nombre, descripcion)}

    @mcp.tool()
    def listar_entidades(novela_id: str, tipo: str = '') -> list[dict]:
        """Consultar las entidades relacionadas con una novela."""
        return db.entities(novela_id, 'local', tipo or None)

    @mcp.tool()
    def proponer_hecho(novela_id: str, entidad_id: str, rama_id: str, propiedad: str, valor_json: str,
                       capitulo: str = '', version_fuente: str = '', inicio: int | None = None,
                       fin: int | None = None) -> dict:
        """Registrar una propuesta sin convertirla en canon. valor_json es un literal JSON."""
        value = json.loads(valor_json)
        return {'claim_id': db.add_claim(novela_id,'local',entidad_id,rama_id,propiedad,value,
                                        chapter=capitulo or None,source_version=version_fuente or None,
                                        valid_from=inicio,valid_to=fin)}

    @mcp.tool()
    def consultar_hechos(novela_id: str, entidad_id: str, rama_id: str = '') -> list[dict]:
        """Consultar procedencia, estado y evolución de las afirmaciones."""
        return db.claims(novela_id,'local',entidad_id,rama_id or None)

    @mcp.tool()
    def aprobar_hecho(novela_id: str, afirmacion_id: str, confirmacion_expresa: bool,
                      justificacion: str = 'Confirmado por el escritor') -> dict:
        """APROBACIÓN CONSECUENCIAL: usar únicamente tras autorización explícita del escritor para esta afirmación concreta."""
        if confirmacion_expresa is not True:
            return {'error':'Se requiere confirmación expresa del escritor para esta afirmación'}
        return db.approve_claim(novela_id,'local',afirmacion_id,'escritor',justificacion)

    @mcp.tool()
    def consultar_cronologia(novela_id: str, rama_id: str) -> list[dict]:
        """Leer la cronología de acontecimientos por tiempo de la historia."""
        return db.timeline(novela_id,'local',rama_id)

    @mcp.tool()
    def auditar_continuidad(novela_id: str, rama_id: str, ultimo_orden_escena: int | None = None) -> list[dict]:
        """Detectar contradicciones comprobables y subtramas inactivas."""
        return db.audit(novela_id,'local',rama_id,ultimo_orden_escena)

    @mcp.tool()
    def exportar_novela(novela_id: str) -> dict:
        """Exportar registros en JSON con historial y procedencia."""
        return db.export_novel(novela_id,'local')
    return mcp


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--transport',choices=['stdio','streamable-http'],default='stdio')
    p.add_argument('--port',type=int,default=8765)
    args=p.parse_args()
    mcp=build_server()
    if args.transport=='stdio':mcp.run(transport='stdio')
    else:mcp.run(transport='streamable-http',host='127.0.0.1',port=args.port)

if __name__=='__main__':main()
