# Biblioteca Novelística — Código del servidor autogestionado v0.5.0

Este repositorio incluye el motor de canon y continuidad, FastAPI, adaptador MCP remoto para pruebas y un asistente de instalación segura. **No incluye un servicio ya desplegado ni una integración ChatGPT verificada.**

## Iniciar asistente

`pip install -e '.[api,remote,mcp,test]'`

`biblioteca-wizard`

La elección de infraestructura es por escritor/instalación; nunca se comparten credenciales entre usuarios o con el desarrollador. Lea `docs/INSTALACION_AUTOGESTIONADA.md`.

## Ejecutar pruebas

`pytest -q`

## Alcance

Solo SQLite funciona actualmente. MCP remoto y OAuth necesitan un despliegue HTTPS real y una configuración de proveedor OIDC auténtica; las pruebas locales no validan una sesión de ChatGPT. Distribución exclusiva por ZIP privado.
