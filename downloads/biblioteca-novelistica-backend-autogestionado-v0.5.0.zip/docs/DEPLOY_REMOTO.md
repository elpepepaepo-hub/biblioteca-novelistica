# Despliegue privado — Biblioteca Novelística 0.3.0 (backend)

## Qué entrega
API HTTP con JWT OIDC RS256, bases SQLite aisladas por `sub` y motor de canon de la versión anterior. Cada escritor inicia sesión en **el proveedor de identidad** (Auth0, Supabase Auth u otro OIDC) y el servidor valida el token usando JWKS. Nadie proporciona credenciales SQL. El servidor no implementa registro, login ni OAuth authorization-code; esas pantallas pertenecen al proveedor OIDC.

## Preparación
1. Configura un proveedor de identidad con emisor HTTPS, audiencia propia para la API y JWKS público. Configura clientes OAuth con Authorization Code + PKCE y consentimiento individual.
2. Copia `.env.example` a `.env` y escribe las URLs reales. No incluyas tokens o claves privadas en el repositorio ni en el ZIP.
3. `docker compose up --build -d` en un servidor con disco persistente. El contenedor escucha solo en `127.0.0.1:8080` del anfitrión.
4. Publica un proxy inverso HTTPS con TLS, límites de solicitudes y tamaño, cabeceras seguras, monitoreo y copias de seguridad cifradas. No expongas directamente el puerto 8080.
5. Prueba dos usuarios y confirma que ninguno puede leer los IDs del otro. Restaura un respaldo antes de aceptar manuscritos reales.

## Llamadas
`GET /health` sin credenciales. Para cualquier otro endpoint: `Authorization: Bearer <access_token>` emitido por tu proveedor OIDC para `BIBLIOTECA_OIDC_AUDIENCE`. `GET /novels`, `POST /novels`, etc. La API nunca recibe ni almacena la contraseña de la persona.

## Seguridad y límites actuales
- No usar `BIBLIOTECA_AUTH=off` del prototipo anterior en este servicio: no existe ese modo.
- El servidor verifica firma RS256, expiración, emisor, audiencia y sujeto. Las claves se obtienen de JWKS con caché.
- La base SQLite por usuario está en volumen persistente; el nombre de archivo es SHA-256 del sujeto. No es cifrado de datos en reposo. Activa cifrado de disco y backups.
- Esta arquitectura es apropiada para prototipos pequeños de una sola instancia. **No** usar varias réplicas sobre un volumen SQLite compartido. Para producción multiusuario grande, migrar a PostgreSQL y RLS o controles de tenant equivalentes.
- No hay límites de tamaño, cuotas, rotación de backups, borrado de cuenta ni monitoreo integrados. Son tareas necesarias antes de un lanzamiento abierto.
- Las acciones de aprobación de canon son escrituras sensibles: requieren confirmación explícita en la interfaz; la API solo registra la identidad autenticada y el motivo. El endpoint no puede verificar por sí solo que hubo consentimiento humano.
- No existe todavía un endpoint MCP remoto verificado. **ChatGPT no se conecta a esta API REST por el mero hecho de instalar el ZIP**. La conexión MCP y la experiencia OAuth en ChatGPT son la siguiente integración.
- Mantén el ZIP privado. Compartirlo no provisiona servidores, cuentas ni dominios.
