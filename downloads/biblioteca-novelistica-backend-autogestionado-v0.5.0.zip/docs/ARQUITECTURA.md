# Arquitectura y ruta de evolución

## Estado de v0.2.0 (prototipo local)
- SQLite local mediante `Store`; registro de novelas, entidades, relaciones, afirmaciones, procedencia, escenas, ramas, cronología, cambios, auditorías y subtramas.
- API HTTP local con FastAPI; modo token opcional y modo sin contraseña EXCLUSIVAMENTE loopback.
- Adaptador MCP opcional para clientes con soporte de procesos stdio o endpoint HTTP local.
- Ni el ZIP ni ChatGPT instalan automáticamente un servidor. No hay almacenamiento en la nube ni integración MCP publicada.
- No existe todavía interfaz MCP App interactiva. Sus futuras vistas pueden consumir los modelos y la API.

## Acceso fácil para el escritor final (v0.3+)

**Experiencia objetivo:** el usuario abre el complemento en ChatGPT → pulsa Conectar → accede por OAuth (cuenta propia) → el complemento obtiene permisos limitados para consultar sus novelas → el servidor MCP utiliza un token de usuario y lo traduce a un identificador de propietario → las consultas a PostgreSQL se filtran por el propietario.

El usuario **NUNCA** debería pegar credenciales SQL ni `service_role` de Supabase en ChatGPT. Las credenciales de BD solo residen en el backend y en un gestor seguro de secretos. Un usuario normal únicamente se autentica ante el proveedor OAuth.

Para modo individual offline se puede desactivar la autenticación HTTP cuando el servidor está limitado a 127.0.0.1. No usar `off` con puertos abiertos a Internet, túneles, proxies inversos o red local. La autenticación para acceso remoto no debe ser opcional. En un servicio multiusuario, autenticar siempre y enlazar cada petición con una identidad verificada, usando aislamiento por usuario y pruebas de acceso cruzado. Configuración de autenticación se define por *instalación*, no por una preferencia que cualquiera pueda desactivar a distancia.

## Modelo conceptual
- `novel`: universo y propietario.
- `branch`: rama principal o alternativa.
- `entity`: personajes, lugares, acontecimientos, reglas, organizaciones, objetos y subtramas.
- `claim`: un hecho acerca de una entidad, una propiedad y su valor estructurado; referencia capítulo, escena, documento, versión, fecha; vigencia por intervalos.
- `canon_decision`: actor, decisión, justificación y momento.
- `event_time`: tiempo en la historia independiente de orden narrativo. `calendar` permite calendarios ficticios; ticks son unidades definidas por el escritor.
- `entity_relation`: relación tipada; todavía no cuenta con flujo de aprobación.
- `issue`: evidencia de conflictos y clasificación.

## Limitaciones técnicas pendientes
- El detector compara valores de una misma propiedad y rama cuando sus intervalos se superponen; desconoce contradicciones semánticas entre propiedades diferentes. Estas requieren reglas adicionales o análisis editorial asistido.
- Los `ticks` son enteros relativos; no hay conversión automática entre calendarios ficticios ni anacronismos semánticos complejos.
- Las afirmaciones canon aprobadas son inmutables en este prototipo; la sustitución controlada requerirá un flujo explícito de retiro/revisión con historial.
- Las ramas alternativas se aíslan; no heredan automáticamente hechos de la rama principal.
- Las relaciones entre entidades se registran como propuesta/alternativa, pero necesitan un procedimiento de aprobación para pasar a canon.
- Los importadores JSON deben ejecutarse solo sobre archivos confiables. Para cargas externas, incorporar validación completa de contenido/tamaño y límites de recursos.
- SQLite no ofrece aislamientos ni infraestructura de producción para usuarios remotos. PostgreSQL y RLS más autenticación OAuth se diseñarán antes del despliegue multiusuario.
- El adaptador MCP y la API local son **dos procesos alternativos**; no equivalen a un MCP App con vistas ni a un servidor conectado a ChatGPT cloud. Una app interactiva requerirá UI con componentes MCP y permisos apropiados.
- Recordatorios automáticos y monitoreo de inactividad requieren un programador en un servidor y consentimiento para notificaciones; no se activan aquí.

## Próximos hitos
1. Diseñar migraciones SQL y RLS PostgreSQL; prueba de aislamiento por `user_id`.
2. Implementar OAuth/OIDC, tokens de acceso y almacenamiento seguro.
3. Exponer MCP con TLS y servidor remoto; registro del endpoint en el complemento sin compartir secretos.
4. Incorporar MCP App (timeline y fichas), controles de confirmación y vistas de diferencias.
5. Integración opcional con herramientas de generación de imagen y notificaciones.
