# MCP remoto y autenticación (v0.4.0, plantilla desplegable)

## Arquitectura
ChatGPT -> OAuth Authorization Code + PKCE en proveedor OIDC -> servidor MCP HTTPS -> verificación JWT RS256 -> subject del escritor -> SQLite aislado por usuario. Nunca se solicitan contraseñas SQL al escritor.

## Selección del usuario / operador
- Hosting: Render, Railway, Fly.io o Docker autogestionado.
- Identidad: Auth0, Keycloak o Amazon Cognito.
- La selección corresponde a **quien despliega el servidor**. Un escritor conectado no puede cambiar de hosting o de proveedor de identidad para un servidor existente: eso supondría otro despliegue y posiblemente migración de cuentas y datos.
- Todos los despliegues requieren configurar URL real HTTPS, emisor, audiencia, JWKS, cliente OAuth, callback URI y volumen persistente.

## Generar plan sin credenciales
```
biblioteca-configure --host render --identity auth0 \
  --public-url https://TU-DOMINIO \
  --issuer https://TU-TENANT.auth0.com/ \
  --audience biblioteca-api \
  --jwks https://TU-TENANT.auth0.com/.well-known/jwks.json
```
Este comando genera un plan, **no** crea cuentas ni despliega infraestructura. El plan no contiene secretos.

## Ejecutar MCP
Instala `pip install -e '.[mcp,remote]'`. Configura `BIBLIOTECA_PUBLIC_URL`, `BIBLIOTECA_OIDC_ISSUER`, `BIBLIOTECA_OIDC_AUDIENCE`, `BIBLIOTECA_OIDC_JWKS_URL`, `BIBLIOTECA_DATA_DIR` y `PORT` en variables de entorno privadas. Ejecuta `biblioteca-mcp-remote`. Usa TLS en el proxy inverso y enruta `/mcp` al proceso.

## Requisitos del proveedor OAuth
- Authorization Code + PKCE, JWT RS256 con `iss`, `aud`, `sub`, `exp`, `iat`.
- Discovery OAuth/OIDC y JWKS accesibles públicamente sobre HTTPS.
- Cliente compatible con la plataforma ChatGPT; configurar los redirect URI exactos proporcionados por la conexión de ChatGPT, nunca inventarlos.
- Aislar usuarios por `iss` + `sub` cuando se admita más de un emisor; esta versión admite **un emisor por despliegue**.
- Proteger contra replay/uso indebido, limitar tasas, supervisar almacenamiento y realizar copias de seguridad antes de producción.
- El ejemplo actual valida JWT y crea herramientas MCP; **no implementa un servidor OAuth propio**.

## Limitaciones y seguridad
- `writer_confirmed` es una bandera de la herramienta; no sustituye confirmación fiable en una UI independiente. Para producción, aprobación de canon debe pasar por confirmación transaccional o autorización humana de la plataforma.
- Los ámbitos de `AccessToken` son metadatos internos del adaptador; se requieren scopes reales comprobados en JWT para autorización granular en producción.
- SQLite por usuario requiere volumen persistente, cifrado/backup y estrategia de migración; PostgreSQL es preferible en despliegue multiinstancia.
- No se ha probado una sesión real de ChatGPT ni un despliegue público: solo pruebas locales y verificación estática.
- El ZIP de plugin **no debe** contener URLs inventadas, tokens ni claves. Añadir `mcp.json` solo tras obtener un endpoint real y verificado.
