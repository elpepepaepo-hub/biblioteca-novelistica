# Biblioteca Novelística — Instalación autogestionada v0.5.0

Cada escritor administra una instalación diferente y sus costes. No existe servidor ni cuentas gestionadas por el creador. No se necesita compartir manuscritos ni secretos con él.

## Modos
- **Sencillo**: directamente en ChatGPT sin infraestructura; fichas y revisiones en el contexto de la conversación. Sin almacenamiento automático. Si se desea una base SQLite local separada, ejecutar el backend local; ChatGPT en nube no accede a localhost automáticamente.
- **Persistente**: cada escritor contrata o administra su propio servicio Docker, su volumen SQLite y su proveedor OAuth/OIDC, y registra un MCP remoto HTTPS compatible.

## Asistente seguro de instalación
Instale Python 3.11+, ejecute `pip install -e '.[api,remote,mcp]'` y después:

```sh
biblioteca-wizard --mode persistente --host railway --database sqlite --auth oauth --identity auth0 --output mi-instalacion
```

Sin argumentos presenta preguntas interactivas, sin contraseñas. El resultado es un PLAN y plantillas; no crea cuentas ni realiza pagos ni despliegues. Para modo sencillo: `biblioteca-wizard --mode sencillo --output mi-instalacion`.

## Proveedores compatibles
- Hosting: Render, Railway, Fly.io, VPS autogestionado. SQLite exige disco persistente, siempre una instancia escritora. Verifique precios y restricciones del proveedor.
- Identidad: Auth0, Keycloak, Amazon Cognito. Cada escritor debe configurar issuer, audience y JWKS reales, además del OAuth Authorization Code + PKCE con los redireccionamientos exactos facilitados por ChatGPT. Keycloak requiere operar su propio servidor de identidad.
- DB: **solo SQLite** está implementada actualmente. PostgreSQL está planificada y el configurador rechaza su selección para evitar configuraciones engañosas.

## Seguridad obligatoria
- Un servidor remoto sin OAuth queda BLOQUEADO por el asistente, y el programa MCP exige emisor, audiencia y JWKS HTTPS.
- No almacenar contraseñas ni claves en repositorios, ZIP o conversaciones: utilizar paneles de secretos del alojamiento. Los metadatos de identidad que no sean secretos se configuran en el despliegue.
- No exponer el puerto local sin protección. Una instalación `off-local` solo funciona en loopback y nunca debe tunelizarse. Docker local exige token porque el cliente Docker puede parecer remoto al contenedor.
- Realizar copias de seguridad; proteger el volumen; probar exportación, importación y restauración; asegurar TLS, límites de uso y control de acceso a las herramientas.
- Aprobar explícitamente cada cambio de canon; actualmente la llamada `writer_confirmed` depende de un flujo de confirmación de la plataforma, que **aún requiere validación de extremo a extremo**. No usarlo con manuscritos sensibles antes de auditarlo.

## Cómo conectar ChatGPT
Cuando el servicio está alojado en un dominio HTTPS real, registrar la URL `https://DOMINIO_REAL/mcp` mediante una función de conectores MCP que esté disponible en la cuenta. Probar descubrimiento de herramientas, inicio de sesión, rechazo de token caducado, aislamiento de datos y confirmación de cambios de canon. **El ZIP por sí solo no instala el servicio, no configura OAuth y no concede acceso a ChatGPT**.

## Portabilidad
El motor implementa `export_novel` e `import_novel` en el módulo `core.py`. La API remota expone exportación, pero la importación remota requiere un endpoint validado adicional. En esta versión puede recuperarse mediante herramienta administrativa local, después de revisar el respaldo. No incluya archivos `.sqlite3` en el ZIP del plugin.

## Costes y publicación
Distribución privada por ZIP; no se enviará a directorio público. Cada escritor paga y controla su hosting, identidad y almacenamiento según tarifas de terceros. Se recomienda empezar por modo sencillo antes de elegir modo persistente.
