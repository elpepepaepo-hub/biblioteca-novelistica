# Biblioteca Novelística v0.5.0 — Distribución privada

El ZIP del complemento contiene dos modos: sencillo (solo conversación) y persistente (servidor independiente del escritor). El segundo necesita que el escritor despliegue `assets/backend.zip`, elija servicios externos y conecte su URL HTTPS MCP desde la interfaz admitida por su cuenta de ChatGPT. El instalador guía al usuario y bloquea combinaciones públicas sin OAuth; no crea cuentas ni almacena credenciales. Consulte `skills/cerebro-novela/references/instalacion.md`.
