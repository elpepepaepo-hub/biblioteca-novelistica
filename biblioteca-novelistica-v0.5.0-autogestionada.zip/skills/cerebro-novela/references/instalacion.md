# Manual resumido para el escritor

**Sencillo:** no contratar nada ni conectar servidor; usar ChatGPT y exportar registros manualmente.

**Persistente:** descargar `assets/backend.zip`, descomprimir, instalar Python 3.11+, instalar dependencias con `pip install -e '.[api,remote,mcp]'`, ejecutar `biblioteca-wizard` y elegir alojamiento, SQLite y un proveedor OIDC. Seguir el plan generado para desplegar Docker y volúmenes permanentes. Registrar exclusivamente el endpoint HTTPS real `/mcp`, nunca uno inventado.

**Reglas de seguridad:** no pegar tokens ni claves en chat; OAuth obligatorio en remoto; localhost sin OAuth no debe exponerse por túnel/proxy; Docker local requiere token; comprobar precios, backups, certificados y conectividad antes de subir manuscritos.

**Portabilidad:** `export_novel` y `import_novel` existen en el motor Python; la API remota todavía no presenta importación en línea comprobada. El usuario conserva su respaldo y decide cuándo migrar.

**Limitación:** la instalación real requiere cuentas, permisos y capacidades compatibles con ChatGPT; el ZIP contiene instrucciones y código, no infraestructura desplegada.
