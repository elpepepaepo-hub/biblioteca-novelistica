# Formatos portables de la biblia de novela

Guardar en Markdown o JSON segun solicite el autor. Son formatos de salida, no una base de datos conectada.

## Registro de entidad
- ID: ENT-0001
- Tipo: personaje | lugar | suceso | institucion | regla | objeto
- Nombre y alias:
- Estado: CANON CONFIRMADO | PROPUESTA | HIPOTESIS | ALTERNATIVA | DESCONOCIDO | RETIRADO
- Fuente: capitulo/escena/nota del usuario
- Validez temporal: desde/hasta o capitulo/epoca
- Descripcion fisica o espacial:
- Rasgos internos/funcion:
- Motivaciones o causas:
- Secretos (visibles solo al autor):
- Relaciones / dependencias:
- Cambios y consecuencias:
- Imagen canonica: solo cuando se apruebe
- Conflictos pendientes:

## Snapshot temporal
- ID de entidad y revision
- Momento en el mundo / capitulo conocido
- Estado previo
- Evento que causa cambio
- Estado posterior
- Quien lo sabe, y desde cuando
- Fuente y estatus

## Evento cronologico
- ID, fecha/hora canonica o relativa, incertidumbre
- Duracion
- Orden de aparicion en el manuscrito
- Actores y ubicaciones
- Precedencias, consecuencias
- Linea temporal/rama
- Fuente, estatus y contradicciones

## Subtrama
- ID y nombre
- Pregunta dramatica / promesa al lector
- Inicio, avances y ultima referencia conocida
- Personajes y conflictos asociados
- Hitos pendientes y resolucion
- Riesgos de ritmo, material no revisado

## Variante de escena
- ID de rama
- Escena base y version
- Cambio hipotetico
- Secuencia de consecuencias
- Canones afectados
- Estado EXPERIMENTO / DESCARTADA / ELEGIDA
- Aprobacion del autor para pasar a canon (si/no)

## Incidencia editorial
- ID; nivel GRAVE / IMPORTANTE / MENOR; confianza
- Fuente A y fuente B (no inventar)
- Descripcion y consecuencias
- Pregunta de verificacion
- Alternativas para resolver
- Estado ABIERTA / EXPLICADA / CORREGIDA / ACEPTADA INTENCIONALMENTE
